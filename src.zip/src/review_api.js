const review_api = [
    {
        "id": 1,
        "review": 'Had an amazing experience here!. The staff went way beyond to make our long-weekend comfortable and memorable.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 2,
        "review": 'This is a beautiful stay, and the bed is comfortable. The tub is fantastic. Altogether I had a great stay and I hope to book again.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 3,
        "review": 'I  really enjoyed my stay here and think it’s a great way to enjoy  from the comfort of a place that feels like home.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 4,
        "review": 'The apartment was clean, comfortable, and in a great location. He communicates quickly and is very accommodating. Thanks again!',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 5,
        "review": 'We loved our stay! We felt very comfortable, safe, and it was very clean. The location was great, too. We just loved every minute of our visit.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 6,
        "review": 'Top-notch AirBnB experience, polite and accurate communication combined with elegant and well located apartment.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "review": 'I was just crashing for one night before I headed to the airport, but I wish I could have stayed longer. This listing had absolutely everything I needed, down to laundry detergent. I’d recommend it!',
        "id": 7,
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 8,
        "review": 'Had an amazing experience here!. The staff went way beyond to make our long-weekend comfortable and memorable.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 9,
        "review": 'This is a beautiful stay, and the bed is comfortable. The tub is fantastic. Altogether I had a great stay and I hope to book again.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 10,
        "review": 'I  really enjoyed my stay here and think it’s a great way to enjoy  from the comfort of a place that feels like home.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 11,
        "review": 'The apartment was clean, comfortable, and in a great location. He communicates quickly and is very accommodating. Thanks again!',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 12,
        "review": 'We loved our stay! We felt very comfortable, safe, and it was very clean. The location was great, too. We just loved every minute of our visit.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 13,
        "review": 'Top-notch AirBnB experience, polite and accurate communication combined with elegant and well located apartment.',
        "rating": 4.75,
        "source": 'anonymous'
    },
    {
        "id": 14,
        "review": 'I was just crashing for one night before I headed to the airport, but I wish I could have stayed longer. This listing had absolutely everything I needed, down to laundry detergent. I’d recommend it!',
        "rating": 4.75,
        "source": 'anonymous'
    }
]

export default review_api;